from django.contrib import admin

# Register your models here.
from .models import Genero, Cliente
# Register your models here.
admin.site.register(Genero)
admin.site.register(Cliente)