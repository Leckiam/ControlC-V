from django.contrib import admin

# Register your models here.
from .models import Carrito

admin.site.register(Carrito)